package PageElements;

import org.openqa.selenium.By;

public class RegisterPage {
	
	public By username=By.id("user_login");
	public By emailId=By.id("user_email");
	public By password=By.id("user_pass");
	public By confirmPassword=By.id("user_confirm_password");
	public By submit=By.cssSelector("button[type='submit']");
	public By email_errorMsg=By.id("user_email-error");
	public By password_errorMsg=By.id("user_confirm_password-error");
	public By successMsg=By.xpath("//div[@id='ur-submit-message-node']/ul");
	

}
