package StepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import PageElements.RegisterPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.qameta.allure.Allure;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.ByteArrayInputStream;

import static org.junit.Assert.*;

import java.security.SecureRandom;

public class RegistrationSteps {

	WebDriver driver;
	private RegisterPage registerPage;

	public RegistrationSteps(RegisterPage registerPage) {
		this.registerPage = registerPage;
	}

	@Given("Login the registration page")
	public void openRegistration() {
		if (driver == null) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		driver.get("http://demo.wpeverest.com/user-registration/simple-registration-form/");
	}

	@When("Submit the form without filling details")
	public void submitEmptyForm() {
		driver.findElement(registerPage.submit).click();
	}

	@Then("I should see validation error messages")
	public void seeValidationErrors() {
		assertTrue(driver.getPageSource().contains("This field is required"));
		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}

	@When("Enter email as {string} and valid password")
	public void enterInvalidEmail(String email) {
		driver.findElement(registerPage.emailId).sendKeys(email);
		driver.findElement(registerPage.password).sendKeys("Valid@123");
		driver.findElement(registerPage.confirmPassword).sendKeys("Valid@123");
	}

	@When("Enter email and invaild password")
	public void enterInvalidPassword() {
		String number = generateRandomNumbers(4, 9999);
		driver.findElement(registerPage.username).sendKeys("vikramr" + number + "");
		driver.findElement(registerPage.emailId).sendKeys("vikramr" + number + "@gmail.com");
		driver.findElement(registerPage.password).sendKeys("Valid@123");
		driver.findElement(registerPage.confirmPassword).sendKeys("Valid@12");
	}

	@And("Submit the form after entering the details")
	public void submitForm() {
		driver.findElement(registerPage.submit).click();
	}

	@Then("Verify the error as {string}")
	public void verifyEmailError(String msg) {
		attachScreenshot("ErrorMsg", driver);
		WebElement error = driver.findElement(registerPage.email_errorMsg);
		assertEquals(msg, error.getText());
		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}

	@Then("Verify the confirm password mismatch error as {string}")
	public void verifyPasswordError(String msg) throws InterruptedException {
		attachScreenshot("ErrorMsg", driver);
		WebElement error = driver.findElement(registerPage.password_errorMsg);
		assertEquals(msg, error.getText());

		if (msg.equalsIgnoreCase(error.getText())) {
			driver.findElement(registerPage.confirmPassword).clear();
			Thread.sleep(2000);
			driver.findElement(registerPage.confirmPassword).sendKeys("Valid@123");
			driver.findElement(registerPage.submit).click();
		}

		Thread.sleep(5000);
		attachScreenshot("After handling the password mismatch", driver);
		WebElement successmsg = driver.findElement(registerPage.successMsg);
		assertEquals("User successfully registered.", successmsg.getText());
		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}

	@When("Enter valid details")
	public void enterValidDetails() {
		String number = generateRandomNumbers(4, 9999);

		driver.findElement(registerPage.username).sendKeys("vikramr" + number + "");
		driver.findElement(registerPage.emailId).sendKeys("vikramr" + number + "@gmail.com");
		driver.findElement(registerPage.password).sendKeys("vikki@54321");
		driver.findElement(registerPage.confirmPassword).sendKeys("vikki@54321");
	}

	@Then("Verify the success as {string}")
	public void redirectedToSuccessPage(String Message) throws InterruptedException {
		Thread.sleep(5000);
		attachScreenshot("Success", driver);
		WebElement msg = driver.findElement(registerPage.successMsg);
		assertEquals(Message, msg.getText());
		if (driver != null) {
			driver.quit();
			driver = null;
		}

	}

	@Then("Verify the redirected to HTTPS")
	public void checkHttpsRedirect() {
		String currentUrl = driver.getCurrentUrl();
		System.out.println("Redirected URL: " + currentUrl);
		assertTrue("HTTPS is not enforced!", currentUrl.startsWith("https://"));
		if(currentUrl.startsWith("https://")) {
			Allure.addAttachment("", " HTTPS is enforced");
		}
		

		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}
	
	@When ("Enter the invalid input details")
	public void invalidInputSetails() {
		driver.findElement(registerPage.username).sendKeys("123456");
		driver.findElement(registerPage.emailId).sendKeys("123456");
		driver.findElement(registerPage.password).sendKeys("@@@@@");
		driver.findElement(registerPage.confirmPassword).sendKeys("@@@@@");
	}

	public String generateRandomNumbers(int digit, int count) {
		SecureRandom random = new SecureRandom();
		int num = random.nextInt(count);
		return String.format("%0" + digit + "d", num);
	}

	public static void attachScreenshot(String name, WebDriver driver) {
		Allure.addAttachment(name,
				new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
	}
}
